TET Plugin for Adobe Acrobat
============================

The TET Plugin is a freely available packaging of TET which can be used
for testing in Adobe Acrobat and interactive use of TET with any PDF document.

The TET plugin can be downloaded for free from the following location:
http://www.pdflib.com/products/tet-plugin
