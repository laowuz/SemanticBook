Please use the python25 binding for python25, python26 and python30.

Python 2.5, 2.6, and 3.0 use PYTHON_API_VERSION 1013, so they can
all use the same TET binaries.
