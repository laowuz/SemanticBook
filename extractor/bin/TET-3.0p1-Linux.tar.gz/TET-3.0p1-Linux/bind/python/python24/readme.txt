Please use the python23 binding for python24.

Python 2.3 and Python 2.4 use PYTHON_API_VERSION 1012, so they can both
use the same TET binaries.
