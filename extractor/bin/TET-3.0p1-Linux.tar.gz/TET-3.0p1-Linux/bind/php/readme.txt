================================
Notes on the TET binding for PHP
================================


Currently none.
