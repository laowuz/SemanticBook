Notes on the TET Java binding
=============================

(currently none)
